Page({

  /**
   * 页面的初始数据
   */
  data: {
    conArr: [{ mon: "￥ 40 元", name1: "新店优惠", name2: "满 300 元使用", name3: "领取 15 天内有效" },
    { mon: "￥ 25 元", name1: "新店优惠", name2: "满 200 元使用", name3: "领取 15 天内有效" },
    { mon: "￥ 15 元", name1: "新店优惠", name2: "满 100 元使用", name3: "领取 15 天内有效" },
    { mon: "￥ 5 元", name1: "新店优惠", name2: "满 50 元使用", name3: "领取 15 天内有效" }],
    shopArr: [{ src: "../../images/img/11.jpg", txt: "70后妹子", money: "￥ 1200" }, { src: "../../images/img/2.jpg", txt: "80后妹子", money: "￥ 3500" }, { src: "../../images/img/9.jpg", txt: "90后妹子", money: "￥ 3600" }, { src: "../../images/img/5.jpg", txt: "00后妹子", money: "￥ 3000" }, { src: "../../images/img/8.jpg", txt: "70后妹子", money: "￥ 300" }, { src: "../../images/img/16.jpg", txt: "90后妹子", money: "￥ 1000" }, { src: "../../images/img/14.jpg", txt: "80后妹子", money: "￥ 3000" }]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})