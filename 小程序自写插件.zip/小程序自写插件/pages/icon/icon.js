const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list: ['icon-liebiao', 'icon-shouji', 'icon-yiguanzhu', 'icon-weiguanzhu', 'icon-chucuo', 'icon-zhengque', 'icon-fenxiang', 'icon-wo', 'icon-shoucangxuanzhong', 'icon-shoucang', 'icon-daifukuan', 'icon-daifukuan', 'icon-add', 'icon-fenxiang1', 'icon-jia', 'icon-jian', 'icon-31fenxiang', 'icon-31shouyexuanzhong', 'icon-31shouye', 'icon-guanbi', 'icon-31dingwei', 'icon-31chiping', 'icon-31fanhui1', 'icon-31fanhui2', 'icon-shanchu', 'icon-radiobutton', 'icon-zanfill', 'icon-dangdifill', 'icon-zengjia', 'icon-yanzhengma', 'icon-shangxia', 'icon-shangxia1', 'icon-shangxia2', 'icon-shangchuan1', 'icon-tubiao-shangchuan', 'icon-shangchuan','icon-plus-with-border'
    ],
  },




  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})